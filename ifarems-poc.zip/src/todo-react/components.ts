/* eslint-disable */
/* tslint:disable */
/* auto-generated react proxies */
import { createReactComponent } from './react-component-lib';

import type { JSX } from 'todo-app';



export const TodoApp = /*@__PURE__*/createReactComponent<JSX.TodoApp, HTMLTodoAppElement>('todo-app');
export const TodoFooter = /*@__PURE__*/createReactComponent<JSX.TodoFooter, HTMLTodoFooterElement>('todo-footer');
export const TodoHeader = /*@__PURE__*/createReactComponent<JSX.TodoHeader, HTMLTodoHeaderElement>('todo-header');
export const TodoList = /*@__PURE__*/createReactComponent<JSX.TodoList, HTMLTodoListElement>('todo-list');
